#include <stdio.h>

int main() {


    int dogumYili;
    int yas;

    printf("Lutfen dogum yilinizi giriniz:");
    scanf("%d", &dogumYili);

    yas = 2022 - dogumYili;

    if(yas >= 18){
        printf("Yasiniz ehliyet almaya uygundur.");
    }
    else{
        printf("Yasiniz ehliyet almaya uygun degildir.");
    }


    return 0;
}