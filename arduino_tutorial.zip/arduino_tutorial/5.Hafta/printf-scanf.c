#include <stdio.h>

int main(){

    printf("Selamun Aleyküm Dünya \n");
    printf("Buraya ne yazarsam ekrana aynen yazacak\n");

    int sayi;

    printf("Lutfen bir sayi giriniz:");
    scanf("%d",&sayi);

    printf("Ekrana girdiginiz sayi %d",sayi);


    return 0;
}