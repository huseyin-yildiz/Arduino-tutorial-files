#include <stdio.h>

void main(){

    int sayi1;
    int sayi2;

    printf("Bir sayi giriniz:");
    scanf("%d",&sayi1);

    printf("Bir sayi daha giriniz:");
    scanf("%d",&sayi2);

    if(sayi1 > sayi2){
        printf("%d %d den buyuktur.",sayi1, sayi2);
    }

    if(sayi1 < sayi2){
        printf("%d %d den buyuktur.",sayi2, sayi1);
    }

    if(sayi1 == sayi2){
        printf("iki sayi birbirine eşittir.");
    }



    return 0;
}