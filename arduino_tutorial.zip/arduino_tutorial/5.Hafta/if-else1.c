#include <stdio.h>

void main(){

    int sayi;

    printf("Lutfen bir sayi giriniz:");
    scanf("%d",&sayi);      // kullanıcıdan sayi alma


    // sayi 0 dan buyuk mu
    
    if(0 < sayi){
        printf("\n Girdiginiz sayi pozitiftir.");
    }
    else{
        printf("\n Girdiginiz sayi negatiftir.");
    }


    return 0;
}