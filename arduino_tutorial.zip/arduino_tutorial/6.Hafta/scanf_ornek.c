
#include<stdio.h>
// kutuphane --> Belli amaçlara yönelik çeşitli fonksiyonları içeren ortamlar


int main(){

    int sayi;
    


                        
    // & (Ampersand) --> Değişkenin başına yazıldığında adresini verir.      (Aslında bir operatördür.)
    printf("Sayi degiskeninin adresi: %d \n",&sayi);                 




    scanf("%d",&sayi );
    printf("Girilen sayi: %d \n ",sayi);

                        // Yer tutucular --> Koyulduğu yere bir değişken gelir
                        // %d --> integer (tam sayı)
                        // %c --> character (karakter)
                        // %f --> float (virgüllü sayı)
                        // %s --> string (metin)



return 0;
}

