#include<stdio.h>

int main(){


    int sayi1 = 5;
    int sayi2 = 10;

    int sonuc;

    sonuc = sayi1 * sayi2;      // burda * yerine -, +, / ,% (kalanı verir, 7%2 = 1 demektir.) 
    sonuc = 5 / 2;
    sonuc = sayi1 / 3;


    return 0;
}