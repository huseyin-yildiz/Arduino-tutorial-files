
#include<stdio.h>
// kutuphane --> Belli amaçlara yönelik çeşitli fonksiyonları içeren ortamlar


int main(){


    int girilen_sifre
    
    printf("Sifre giriniz:");           //  çift tırnak ("merhaba") içine yazılan metin olarak algılanır. Kod olarak algılanmaz

    // printf(Sifre giriniz);              // Burda hata verir. Çünkü Sifre giriniz metnini kod olarak tanımaya çalışır.

    scanf("%d%c",girilen_sifre );12c

                        // %d --> integer (tam sayı)
                        // %c --> character (karakter)
                        // %f --> float (virgüllü sayı)
                        // %s --> string (metin)



return 0;
}

