#include <stdio.h>

int main(){

    int sayi = 1;

    printf("Buraya ne yazarsam aynen ekrana yazacak");

    printf("Degisken ekrana yazdırmak icin %d kullaniyoruz", sayi);

    // bazı özel karakterlerimiz var (Kaçış karakterleri )
    // \n   --> newline ( alt satıra geçer)
    // \t   --> tab (4 tane boşluk bırakır)
    



    return 0;
}